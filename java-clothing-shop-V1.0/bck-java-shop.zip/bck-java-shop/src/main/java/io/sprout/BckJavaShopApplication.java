package io.sprout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BckJavaShopApplication {
  public static void main(String[] args) {
    SpringApplication.run(BckJavaShopApplication.class, args);
  }
}
