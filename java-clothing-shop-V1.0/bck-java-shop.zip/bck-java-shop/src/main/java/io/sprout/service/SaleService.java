package io.sprout.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.dto.SaleDetailDTO;
import io.sprout.model.Product;
import io.sprout.repository.ISaleRepository;
import io.sprout.repository.record.ProductRecord;
import io.sprout.repository.record.SaleDetailRecord;
import io.sprout.repository.record.SaleRecord;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

@Component
public class SaleService {

  @Autowired
  private ISaleRepository respository;
  @Autowired
  private ObjectMapper mapper;
  @Autowired
  private ProductService serviceProduct;
  @Autowired
  private UtilService util;

  public SaleService() {}

  private Product findProductByPublicKey(String publicKey) {
    Product product = this.serviceProduct.findByPublicKey(publicKey);
    if (product.getPublicKey() == null) {
      throw new EmptyStackException();
    }
    return product;
  }

  private SaleDetailRecord createNewSaleDetailRecord(SaleDetailDTO item) {
    short ammount = item.getAmmount();
    float unitPrice = 0;
    Product product = this.findProductByPublicKey(item.getProduct().getPublicKey());
    ProductRecord productRecord = new ProductRecord(
      product.getPublicKey(),
      product.getName(),
      product.getUnitPrice(),
      product.getAmmount(),
      product.isFlagState(),
      product.isFlagVisible(),
      product.getCreateDate(),
      product.getLastUpdate(),
      null
    );
    SaleDetailRecord result = new SaleDetailRecord(
      ammount,
      unitPrice,
      null,
      productRecord
    );
    return result;
  }

  private List<SaleDetailRecord> createNewListSaleDetailRecords(List<SaleDetailDTO> listProducts) {
    SaleDetailRecord saleDetailRecord = null;
    List<SaleDetailRecord> listSaleDetailRecords = new LinkedList<SaleDetailRecord>();
    for (SaleDetailDTO item : listProducts) {
      saleDetailRecord = this.createNewSaleDetailRecord(item);
      listSaleDetailRecords.add(saleDetailRecord);
    }
    return listSaleDetailRecords;
  }

  private SaleRecord createNewSaleRecord(String publicKey, List<SaleDetailRecord> listSaleDetails) {
    Date date = new Date();
    SaleRecord saleRecord = new SaleRecord(publicKey, true, true, date, null, listSaleDetails);
    return saleRecord;
  }

  public SaleRecord save(List<SaleDetailDTO> listProducts) {
    String salePublicKey = null;
    String textListProduct = null;
    String textListSoldProducts = null;
    SaleRecord saleRecord = null;
    List<SaleDetailRecord> resultSaleDetailsRecords = null;
    List<SaleDetailRecord> listSaleDetailRecords = null;
    try {
      salePublicKey = this.util.createPublicKey();
      listSaleDetailRecords = this.createNewListSaleDetailRecords(listProducts);
      textListProduct = this.mapper.writeValueAsString(listSaleDetailRecords);
      textListSoldProducts = this.respository.saveSale(salePublicKey, textListProduct);
      resultSaleDetailsRecords = this.mapper.readValue(textListSoldProducts, new TypeReference<List<SaleDetailRecord>>() {});
      saleRecord = this.createNewSaleRecord(salePublicKey, resultSaleDetailsRecords);
      return saleRecord;
    } catch (Exception exc) {
      saleRecord = new SaleRecord(null, false, false, null, null, null);
      return saleRecord;
    }
  }

  public float getTotalPurchase(SaleRecord saleRecord) {
    float total = 0;
    for (SaleDetailRecord record : saleRecord.list_sale_details()) {
      total = total + (record.unit_price() * record.ammount());
    }
    return total;
  }

  public List<SaleRecord> findAll(String publicKey, Date date) {
    String textListSaleRecords = null;
    List<SaleRecord> resultSaleRecord = null;
    try {
      textListSaleRecords = this.respository.findAllSalesByFilters(publicKey, date);
      resultSaleRecord = this.mapper.readValue(textListSaleRecords, new TypeReference<List<SaleRecord>>() {});
      return resultSaleRecord;
    } catch (Exception exc) {
      resultSaleRecord = new ArrayList<SaleRecord>();
      return resultSaleRecord;
    }
  }
}
