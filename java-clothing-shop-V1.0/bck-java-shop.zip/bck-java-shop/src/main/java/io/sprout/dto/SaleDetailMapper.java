package io.sprout.dto;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.repository.record.SaleDetailRecord;

@Component
public class SaleDetailMapper {

  @Autowired
  private ProductMapper mapperProduct;

  public SaleDetailMapper() {}

  public SaleDetailDTO toSaleDetailDTO(SaleDetailRecord saleDetailRecord) {
    short ammount = saleDetailRecord.ammount();
    float unitPrice = saleDetailRecord.unit_price();
    ProductDTO product = this.mapperProduct.toSimpleProductDTO(saleDetailRecord.product());
    SaleDetailDTO saleDetailDTO = new SaleDetailDTO(
      ammount,
      unitPrice,
      null,
      product
    );
    return saleDetailDTO;
  }

  public List<SaleDetailDTO> toListSaleDetailDTO(List<SaleDetailRecord> listRecords) {
    SaleDetailDTO saleDetailDTO = null;
    List<SaleDetailDTO> listSaleDetailDTO = new LinkedList<SaleDetailDTO>();
    for (SaleDetailRecord item : listRecords) {
      saleDetailDTO = this.toSaleDetailDTO(item);
      listSaleDetailDTO.add(saleDetailDTO);
    }
    return listSaleDetailDTO;
  }
}
