package io.sprout.repository.record;

import java.util.Date;

public record ProductRecord(
  String public_key,
  String name,
  float unit_price,
  short ammount,
  boolean flag_state,
  boolean flag_visible,
  Date create_date,
  Date last_update,
  CategoryRecord category
) {

  public String public_key() {
    return public_key;
  }

  public String name() {
    return name;
  }

  public float unit_price() {
    return unit_price;
  }

  public short ammount() {
    return ammount;
  }

  public boolean flag_state() {
    return flag_state;
  }

  public boolean flag_visible() {
    return flag_visible;
  }

  public Date create_date() {
    return create_date;
  }

  public Date last_update() {
    return last_update;
  }

  public CategoryRecord category() {
    return category;
  }
}
