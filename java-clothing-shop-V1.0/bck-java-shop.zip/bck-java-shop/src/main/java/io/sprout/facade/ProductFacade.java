package io.sprout.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.dto.ProductDTO;
import io.sprout.dto.ProductMapper;
import io.sprout.model.Product;
import io.sprout.repository.record.ProductRecord;
import io.sprout.service.ProductService;

@Component
public class ProductFacade {

  @Autowired
  private ProductService service;
  @Autowired
  private ProductMapper mapper;

  public ProductFacade() {}

  public ProductDTO save(ProductDTO data) {
    Product product = null;
    ProductDTO information = null;
    ProductDTO productDTO = null;
    try {
      information = this.mapper.toNewProductDTO(data);
      product = this.service.save(information);
      productDTO = this.mapper.toProductDTO(product);
      return productDTO;
    } catch (Exception exc) {
      productDTO = new ProductDTO();
      return productDTO;
    }
  }

  public List<ProductDTO> saveBulk(List<ProductDTO> data) {
    List<ProductDTO> information = null;
    List<ProductDTO> listProductsDTO = null;
    List<ProductRecord> listProductsRecords = null;
    try {
      information = this.mapper.toNewListProductsDTO(data);
      listProductsRecords = this.service.saveBulk(information);
      listProductsDTO = this.mapper.toListProductsDTO(listProductsRecords);
      return listProductsDTO;
    } catch (Exception exc) {
      listProductsDTO = new ArrayList<ProductDTO>();
      return listProductsDTO;
    }
  }

  public ProductDTO update(ProductDTO data) {
    Product product = null;
    ProductDTO information = null;
    ProductDTO productDTO = null;
    try {
      information = this.mapper.toProductDTO(data);
      product = this.service.update(information);
      productDTO = this.mapper.toProductDTO(product);
      return productDTO;
    } catch (Exception exc) {
      productDTO = new ProductDTO();
      return productDTO;
    }
  }

  public ProductDTO shift(ProductDTO data) {
    Product product = null;
    ProductDTO information = null;
    ProductDTO productDTO = null;
    try {
      information = this.mapper.toShiftedProductDTO(data);
      product = this.service.shift(information);
      productDTO = this.mapper.toProductDTO(product);
      return productDTO;
    } catch (Exception exc) {
      productDTO = new ProductDTO();
      return productDTO;
    }
  }

  public ProductDTO delete(String publicKey) {
    Product product = null;
    ProductDTO productDTO = null;
    try {
      product = this.service.delete(publicKey);
      productDTO = this.mapper.toProductDTO(product);
      return productDTO;
    } catch (Exception exc) {
      productDTO = new ProductDTO();
      return productDTO;
    }
  }

  public List<ProductDTO> findAllByFilters(
    String publicKey,
    String name,
    boolean flagState,
    boolean flagVisible,
    String categoryPublicKey
  ) {
    List<ProductRecord> listProductsRecords = this.service.findAllByFilters(
      publicKey,
      name,
      flagState,
      flagVisible,
      categoryPublicKey
    );
    List<ProductDTO> listProductsDTO = this.mapper.toListProductsDTO(listProductsRecords);
    return listProductsDTO;
  }
}
