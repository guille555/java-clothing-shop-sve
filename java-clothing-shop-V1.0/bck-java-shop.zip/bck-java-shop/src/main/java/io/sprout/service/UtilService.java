package io.sprout.service;

import java.util.Random;

import org.springframework.stereotype.Component;

@Component
public class UtilService {

  public UtilService() {}

  public String createPublicKey() {
    int position = 0;
    char letter = ' ';
    Random random = new Random();
    String textTemplate = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    String result = null;
    StringBuilder builder = new StringBuilder();
    for (int index = 0; index < 20; index++) {
      position = random.nextInt(textTemplate.length());
      letter = textTemplate.charAt(position);
      builder.append(letter);
    }
    result = builder.toString();
    return result;
  }
}
