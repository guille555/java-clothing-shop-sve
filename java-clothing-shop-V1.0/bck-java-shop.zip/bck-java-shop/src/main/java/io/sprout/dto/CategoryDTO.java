package io.sprout.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CategoryDTO {

  private String publicKey;
  private String name;
  private Boolean flagState;
  private Boolean flagVisible;
  private Date createDate;
  private Date lastUpdate;
  private List<ProductDTO> listProducts;

  public CategoryDTO() {
    this.publicKey = null;
    this.name = null;
    this.flagState = false;
    this.flagVisible = false;
    this.createDate = null;
    this.lastUpdate = null;
    this.listProducts = new ArrayList<ProductDTO>();
  }

  public CategoryDTO(
    String name
  ) {
    this();
    this.name = name;
  }

  public CategoryDTO(
    String publicKey,
    String name,
    Boolean flagState,
    Boolean flagVisible
  ) {
    this();
    this.publicKey = publicKey;
    this.name = name;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
  }

  public CategoryDTO(
    String publicKey,
    Boolean flagState,
    Boolean flagVisible
  ) {
    this();
    this.publicKey = publicKey;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
  }

  public CategoryDTO(
    String publicKey,
    String name,
    Boolean flagState,
    Boolean flagVisible,
    Date createDate,
    Date lastUpdate,
    List<ProductDTO> listProducts
  ) {
    this.publicKey = publicKey;
    this.name = name;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
    this.createDate = createDate;
    this.lastUpdate = lastUpdate;
    this.listProducts = listProducts;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public String getName() {
    return name;
  }

  public Boolean getFlagState() {
    return flagState;
  }

  public Boolean getFlagVisible() {
    return flagVisible;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public Date getLastUpdate() {
    return lastUpdate;
  }

  public List<ProductDTO> getListProducts() {
    return listProducts;
  }
}
