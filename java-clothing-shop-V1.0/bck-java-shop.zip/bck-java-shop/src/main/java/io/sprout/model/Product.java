package io.sprout.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedAttributeNode;
import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.NamedEntityGraphs;
import jakarta.persistence.NamedStoredProcedureQueries;
import jakarta.persistence.NamedStoredProcedureQuery;
import jakarta.persistence.NamedSubgraph;
import jakarta.persistence.OneToMany;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureParameter;
import jakarta.persistence.Table;

@Entity
@Table(name = "product")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NamedStoredProcedureQueries({
  @NamedStoredProcedureQuery(
    name = "Product.saveBulk",
    procedureName = "sp_bulk_insert_products",
    parameters = {
      @StoredProcedureParameter(mode = ParameterMode.IN, name = "par_list_objects", type = String.class),
      @StoredProcedureParameter(mode = ParameterMode.OUT, name = "par_result_list", type = String.class)
    }
  )
})
@NamedEntityGraphs({
  @NamedEntityGraph(
    name = "Product.allAttributes",
    attributeNodes = {
      @NamedAttributeNode("id"),
      @NamedAttributeNode("publicKey"),
      @NamedAttributeNode("name"),
      @NamedAttributeNode("unitPrice"),
      @NamedAttributeNode("ammount"),
      @NamedAttributeNode("flagState"),
      @NamedAttributeNode("flagVisible"),
      @NamedAttributeNode("createDate"),
      @NamedAttributeNode("lastUpdate"),
      @NamedAttributeNode(value = "category", subgraph = "product-category")
    },
    subgraphs = {
      @NamedSubgraph(
        name = "product-category",
        attributeNodes = {
          @NamedAttributeNode("publicKey"),
          @NamedAttributeNode("name"),
          @NamedAttributeNode("flagState"),
          @NamedAttributeNode("flagVisible"),
          @NamedAttributeNode("createDate"),
          @NamedAttributeNode("lastUpdate")
      })
    }
  ),
  @NamedEntityGraph(
    name = "Product.selfAttributes",
    includeAllAttributes = false,
    attributeNodes = {
      @NamedAttributeNode("id"),
      @NamedAttributeNode("publicKey"),
      @NamedAttributeNode("name"),
      @NamedAttributeNode("unitPrice"),
      @NamedAttributeNode("ammount"),
      @NamedAttributeNode("flagState"),
      @NamedAttributeNode("flagVisible"),
      @NamedAttributeNode("createDate"),
      @NamedAttributeNode("lastUpdate")
    }
  )
})
public class Product extends AbstractSeed implements Serializable {

  private static final long serialVersionUID = -4838179906555737567L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "product_id", nullable = false, insertable = false, updatable = false, unique = true)
  private Integer id;
  @Column(length = 64, nullable = false)
  private String name;
  @Column(name = "unit_price", nullable = false)
  private float unitPrice;
  @Basic(optional = false)
  private short ammount;
  @ManyToOne
  @JoinColumn(
    name = "category_id",
    nullable = false,
    referencedColumnName = "category_id",
    foreignKey = @ForeignKey(
      name = "fk_product_category"
    )
  )
  private Category category;
  @OneToMany(mappedBy = "product")
  private List<SaleDetail> listSaleDetails;

  public Product() {
    super();
    this.id = 0;
    this.listSaleDetails = new LinkedList<SaleDetail>();
  }

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public float getUnitPrice() {
    return unitPrice;
  }

  public void setUnitPrice(float unitPrice) {
    this.unitPrice = unitPrice;
  }

  public short getAmmount() {
    return ammount;
  }

  public void setAmmount(short ammount) {
    this.ammount = ammount;
  }

  public Category getCategory() {
    return category;
  }

  public void setCategory(Category category) {
    this.category = category;
  }

  public List<SaleDetail> getListSaleDetails() {
    return listSaleDetails;
  }

  public void setListSaleDetails(List<SaleDetail> listSaleDetails) {
    this.listSaleDetails = listSaleDetails;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof Product))
      return false;
    Product other = (Product) obj;
    return Objects.equals(id, other.id);
  }

  @Override
  public String toString() {
    return "Product {}";
  }

  @Override
  public String objectInfo() {
    StringBuilder builder = new StringBuilder();
    builder.append("Product: { ");
    builder.append(" id: ");
    builder.append(this.id);
    builder.append(" publicKey: ");
    builder.append(this.publicKey);
    builder.append(" name: ");
    builder.append(this.name);
    builder.append(" ammount: ");
    builder.append(this.ammount);
    builder.append(" flagState: ");
    builder.append(this.flagState);
    builder.append(" flagVisible: ");
    builder.append(this.flagVisible);
    builder.append(" createDate: ");
    builder.append(this.createDate);
    builder.append(" lastUpdate: ");
    builder.append(this.lastUpdate);
    builder.append(" category: ");
    builder.append(" object ");
    builder.append(" }");
    return builder.toString();
  }
}