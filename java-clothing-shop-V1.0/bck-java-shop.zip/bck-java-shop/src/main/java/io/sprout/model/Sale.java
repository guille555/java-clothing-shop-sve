package io.sprout.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.NamedAttributeNode;
import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.NamedEntityGraphs;
import jakarta.persistence.NamedStoredProcedureQueries;
import jakarta.persistence.NamedStoredProcedureQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureParameter;
import jakarta.persistence.Table;

@Entity
@Table(name = "sale")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NamedStoredProcedureQueries({
  @NamedStoredProcedureQuery(
    name = "Sale.saveSale",
    procedureName = "sp_save_sale",
    parameters = {
      @StoredProcedureParameter(name = "par_sale_public_key", mode = ParameterMode.IN, type = String.class),
      @StoredProcedureParameter(name = "par_list_products", mode = ParameterMode.IN, type = String.class),
      @StoredProcedureParameter(name = "par_result_list", mode = ParameterMode.OUT, type = String.class)
    }
  )
})
@NamedEntityGraphs({
  @NamedEntityGraph(
    name = "Sale.allAttributes",
    attributeNodes = {
      @NamedAttributeNode(value = "id"),
      @NamedAttributeNode(value = "publicKey"),
      @NamedAttributeNode(value = "flagState"),
      @NamedAttributeNode(value = "flagVisible"),
      @NamedAttributeNode(value = "createDate"),
      @NamedAttributeNode(value = "lastUpdate"),
      @NamedAttributeNode(value = "listSaleDetails")
    }
  )
})
public class Sale extends AbstractSeed implements Serializable {

  private static final long serialVersionUID = 7142032409584079426L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "sale_id", nullable = false, insertable = false, updatable = false, unique = true)
  private Long id;
  @OneToMany(mappedBy = "sale")
  private List<SaleDetail> listSaleDetails;

  public Sale() {
    super();
    this.listSaleDetails = new LinkedList<SaleDetail>();
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public List<SaleDetail> getListSaleDetails() {
    return listSaleDetails;
  }

  public void setListSaleDetails(List<SaleDetail> listSaleDetails) {
    this.listSaleDetails = listSaleDetails;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof Sale))
      return false;
    Sale other = (Sale) obj;
    return Objects.equals(id, other.id);
  }

  @Override
  public String toString() {
    return "Sale {}";
  }

  @Override
  public String objectInfo() {
    String result = null;
    StringBuilder builder = new StringBuilder();
    builder.append("Sale: { ");
    builder.append(" id: ");
    builder.append(this.id);
    builder.append(" flagState: ");
    builder.append(this.flagState);
    builder.append(" flagVisible: ");
    builder.append(this.flagVisible);
    builder.append(" createDate: ");
    builder.append(this.createDate);
    builder.append(" lastUpdate: ");
    builder.append(this.lastUpdate);
    builder.append(" }");
    result = builder.toString();
    return result;
  }
}
