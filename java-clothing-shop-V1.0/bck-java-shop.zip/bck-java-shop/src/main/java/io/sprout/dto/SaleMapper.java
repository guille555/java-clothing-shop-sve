package io.sprout.dto;

import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.repository.record.SaleRecord;

@Component
public class SaleMapper {

  @Autowired
  private ProductMapper mapperProduct;
  @Autowired
  private SaleDetailMapper mapperSaleDetail;

  public SaleMapper() {}

  private String filterPublicKey(String publicKey) {
    boolean controlLength = (publicKey.trim().length() == 20) ? (false) : (true);
    if (controlLength) {
      throw new EmptyStackException();
    }
    return publicKey;
  }

  private short filterAmmount(short ammount) {
    boolean controlMin = (ammount > 0) ? (false) : (true);
    if (controlMin) {
      throw new EmptyStackException();
    }
    return ammount;
  }

  public SaleDetailDTO toNewSaleDetailDTO(SaleDetailDTO item) {
    short ammount = this.filterAmmount(item.getAmmount());
    ProductDTO product = this.mapperProduct.toSimpleProductDTO(item.getProduct());
    SaleDetailDTO saleItem = new SaleDetailDTO(ammount, product);
    return saleItem;
  }

  public List<SaleDetailDTO> toNewListSaleDetailDTO(List<SaleDetailDTO> data) {
    SaleDetailDTO temporal = null;
    List<SaleDetailDTO> listSaleDetails = new LinkedList<SaleDetailDTO>();
    for (SaleDetailDTO item : data) {
      temporal = this.toNewSaleDetailDTO(item);
      listSaleDetails.add(temporal);
    }
    return listSaleDetails;
  }

  public SaleDTO toSaleDTO(SaleRecord saleRecord, float total) {
    String publicKey = this.filterPublicKey(saleRecord.public_key());
    List<SaleDetailDTO> listSaleDetailsDTO = this.mapperSaleDetail.toListSaleDetailDTO(saleRecord.list_sale_details());
    SaleDTO saleDTO = new SaleDTO(
      publicKey,
      saleRecord.flag_state(),
      saleRecord.flag_visible(),
      total,
      saleRecord.create_date(),
      listSaleDetailsDTO
    );
    return saleDTO;
  }
}
