package io.sprout.repository;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.sprout.model.Category;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface ICategoryRepository extends JpaRepository<Category, Short> {

  @Procedure(name = "Category.saveBulk")
  public abstract String saveBulk(
    @Param("par_list_objects") String text
  );

  @EntityGraph(value = "Category.allAttributes")
  public abstract Category findByPublicKey(String publicKey);

  @Query(value = "SELECT fn_filter_categories(:publicKey, :name, :flagState, :flagVisible) AS result", nativeQuery = true)
  public abstract String findAllByFilters(
    @Param("publicKey") String publicKey,
    @Param("name") String name,
    @Param("flagState") boolean flagState,
    @Param("flagVisible") boolean flagVisible
  );
}
