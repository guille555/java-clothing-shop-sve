package io.sprout.dto;

import java.util.Date;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Component;

import io.sprout.model.Category;
import io.sprout.model.Product;
import io.sprout.repository.record.CategoryRecord;

@Component
public class CategoryMapper {

  public CategoryMapper() {}

  private String filterFieldPublicKey(String publicKey) {
    boolean controlEmpty = (publicKey.trim().length() == 20) ? (false) : (true);
    if (controlEmpty) {
      throw new EmptyStackException();
    }
    return publicKey;
  }

  private String filterFieldName(String name) {
    boolean controlMin = (name.trim().length() > 0) ? (false) : (true);
    boolean controlMax = (name.trim().length() <= 32) ? (false) : (true);
    boolean control = controlMin || controlMax;
    if (control) {
      throw new EmptyStackException();
    }
    return name;
  }

  public Category toCategory(CategoryDTO categoryDTO) {
    String publicKey = this.filterFieldName(categoryDTO.getPublicKey());
    String name = this.filterFieldName(categoryDTO.getName());
    Boolean flagState = categoryDTO.getFlagState();
    Boolean flagVisible = categoryDTO.getFlagVisible();
    Date createDate = categoryDTO.getCreateDate();
    Date lastUpdate = categoryDTO.getLastUpdate();
    List<Product> listProducts = null;
    Category category = new Category();
    category.setPublicKey(publicKey);
    category.setName(name);
    category.setFlagState(flagState.booleanValue());
    category.setFlagVisible(flagVisible.booleanValue());
    category.setCreateDate(createDate);
    category.setLastUpdate(lastUpdate);
    category.setListProducts(listProducts);
    return category;
  }

  public CategoryDTO toNewCategoryDTO(CategoryDTO data) {
    String name = this.filterFieldName(data.getName());
    CategoryDTO result = new CategoryDTO(name);
    return result;
  }

  public CategoryDTO toCategoryDTO(Category category) {
    String publicKey = this.filterFieldPublicKey(category.getPublicKey());
    String name = this.filterFieldName(category.getName());
    boolean flagState = category.isFlagState();
    boolean flagVisible = category.isFlagVisible();
    Date createDate = category.getCreateDate();
    Date lastUpdate = category.getLastUpdate();
    List<ProductDTO> listProductsDTO = null;// replace with a call to function to mapper produictDTO to parse list
    CategoryDTO categoryDTO = new CategoryDTO(
      publicKey,
      name,
      flagState,
      flagVisible,
      createDate,
      lastUpdate,
      listProductsDTO
    );
    return categoryDTO;
  }

  public CategoryDTO toCategoryDTO(CategoryRecord categoryRecord) {
    String publicKey = categoryRecord.public_key();
    String name = categoryRecord.name();
    boolean flagState = categoryRecord.flag_state();
    boolean flagVisible = categoryRecord.flag_visible();
    Date createDate = categoryRecord.create_date();
    Date lastUpdate = categoryRecord.last_update();
    List<ProductDTO> listProductsDTO = null;
    CategoryDTO cateogryDTO = new CategoryDTO(
      publicKey,
      name,
      flagState,
      flagVisible,
      createDate,
      lastUpdate,
      listProductsDTO
    );
    return cateogryDTO;
  }

  public CategoryDTO toCategoryDTO(CategoryDTO categoryDTO) {
    String publicKey = this.filterFieldPublicKey(categoryDTO.getPublicKey());
    String name = this.filterFieldName(categoryDTO.getName());
    Boolean flagState = categoryDTO.getFlagState();
    Boolean flagVisible = categoryDTO.getFlagVisible();
    Date createDate = categoryDTO.getCreateDate();
    Date lastUpdate = categoryDTO.getLastUpdate();
    CategoryDTO cateogryDTO = new CategoryDTO(
      publicKey,
      name,
      flagState,
      flagVisible,
      createDate,
      lastUpdate,
      null
    );
    return cateogryDTO;
  }

  public List<CategoryDTO> toNewListCategoryDTO(List<CategoryDTO> data) {
    CategoryDTO categoryDTO = null;
    List<CategoryDTO> listCategoriresDTO = new LinkedList<CategoryDTO>();
    for (CategoryDTO item : data) {
      categoryDTO = this.toNewCategoryDTO(item);
      listCategoriresDTO.add(categoryDTO);
    }
    return listCategoriresDTO;
  }

  public List<CategoryDTO> toListCategoryDTO(List<CategoryRecord> listRecords) {
    CategoryDTO categoryDTO = null;
    List<CategoryDTO> listCategoriesDTO = new LinkedList<CategoryDTO>();
    for (CategoryRecord item : listRecords) {
      categoryDTO = this.toCategoryDTO(item);
      listCategoriesDTO.add(categoryDTO);
    }
    return listCategoriesDTO;
  }
}
