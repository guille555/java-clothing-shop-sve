package io.sprout.dto;

import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.model.Product;
import io.sprout.repository.record.ProductRecord;

@Component
public class ProductMapper {

  @Autowired
  private CategoryMapper mapperCategory;

  public ProductMapper() {}

  private String filterPublicKey(String publicKey) {
    boolean controlLength = (publicKey.trim().length() == 20) ? (false) : (true);
    if (controlLength) {
      throw new EmptyStackException();
    }
    return publicKey;
  }

  private String filterName(String name) {
    boolean controlMin = (name.trim().length() > 0) ? (false) : (true);
    boolean controlMax = (name.trim().length() <= 64) ? (false) : (true);
    boolean control = controlMin || controlMax;
    if (control) {
      throw new EmptyStackException();
    }
    return name;
  }

  private Float filterUnitPrice(Float unitPrice) {
    boolean controlMin = (unitPrice.floatValue() > 0) ? (false) : (true);
    if (controlMin) {
      throw new EmptyStackException();
    }
    return unitPrice;
  }

  private Short filterAmmount(Short ammount) {
    boolean controlMin = (ammount.shortValue() > 0) ? (false) : (true);
    if (controlMin) {
      throw new EmptyStackException();
    }
    return ammount;
  }

  public ProductDTO toNewProductDTO(ProductDTO data) {
    String name = this.filterName(data.getName());
    Float unitPrice = this.filterUnitPrice(data.getUnitPrice());
    Short ammount = this.filterAmmount(data.getAmmount());
    CategoryDTO categoryDTO = this.mapperCategory.toCategoryDTO(data.getCategory());
    ProductDTO productDTO = new ProductDTO(name, unitPrice, ammount, categoryDTO);
    return productDTO;
  }

  public ProductDTO toShiftedProductDTO(ProductDTO productDTO) {
    String publicKey = this.filterPublicKey(productDTO.getPublicKey());
    ProductDTO result = new ProductDTO(publicKey, productDTO.getFlagState().booleanValue(), productDTO.getFlagVisible().booleanValue());
    return result;
  }

  public ProductDTO toSimpleProductDTO(ProductDTO productDTO) {
    short ammount = this.filterAmmount(productDTO.getAmmount());
    float unitPrice = this.filterUnitPrice(productDTO.getUnitPrice());
    String publicKey = this.filterPublicKey(productDTO.getPublicKey());
    String name = this.filterName(productDTO.getName());
    ProductDTO result = new ProductDTO(
      publicKey,
      name,
      unitPrice,
      ammount,
      productDTO.getFlagState(),
      productDTO.getFlagVisible(),
      productDTO.getCreateDate(),
      productDTO.getLastUpdate(),
      null,
      null
    );
    return result;
  }

  public ProductDTO toSimpleProductDTO(ProductRecord productRecord) {
    short ammount = productRecord.ammount();
    float unitPrice = productRecord.unit_price();
    String publicKey = productRecord.public_key();
    String name = productRecord.name();
    ProductDTO result = new ProductDTO(
      publicKey,
      name,
      unitPrice,
      ammount,
      productRecord.flag_state(),
      productRecord.flag_visible(),
      productRecord.create_date(),
      productRecord.last_update(),
      null,
      null
    );
    return result;
  }

  public ProductDTO toProductDTO(Product product) {
    String publicKey = this.filterPublicKey(product.getPublicKey());
    String name = this.filterName(product.getName());
    short ammount = this.filterAmmount(product.getAmmount());
    float unitPrice = this.filterUnitPrice(product.getUnitPrice());
    CategoryDTO category = this.mapperCategory.toCategoryDTO(product.getCategory());
    ProductDTO result = new ProductDTO(
      publicKey,
      name,
      unitPrice,
      ammount,
      product.isFlagState(),
      product.isFlagVisible(),
      product.getCreateDate(),
      product.getLastUpdate(),
      category,
      null
    );
    return result;
  }

  public ProductDTO toProductDTO(ProductRecord productRecord) {
    String publicKey = productRecord.public_key();
    String name = productRecord.name();
    short ammount = productRecord.ammount();
    float unitPrice = productRecord.unit_price();
    CategoryDTO category = this.mapperCategory.toCategoryDTO(productRecord.category());
    ProductDTO result = new ProductDTO(
      publicKey,
      name,
      unitPrice,
      ammount,
      productRecord.flag_state(),
      productRecord.flag_visible(),
      productRecord.create_date(),
      productRecord.last_update(),
      category,
      null
    );
    return result;
  }

  public ProductDTO toProductDTO(ProductDTO productDTO) {
    String publicKey = this.filterPublicKey(productDTO.getPublicKey());
    String name = this.filterName(productDTO.getName());
    short ammount = this.filterAmmount(productDTO.getAmmount());
    float unitPrice = this.filterUnitPrice(productDTO.getUnitPrice());
    CategoryDTO category = this.mapperCategory.toCategoryDTO(productDTO.getCategory());
    ProductDTO result = new ProductDTO(
      publicKey,
      name,
      unitPrice,
      ammount,
      productDTO.getFlagState(),
      productDTO.getFlagVisible(),
      productDTO.getCreateDate(),
      productDTO.getLastUpdate(),
      category,
      null
    );
    return result;
  }

  public List<ProductDTO> toListProductsDTO(List<ProductRecord> listProductsRecords) {
    ProductDTO productDTO = null;
    List<ProductDTO> listProductsDTO = new LinkedList<ProductDTO>();
    for (ProductRecord item : listProductsRecords) {
      productDTO = this.toProductDTO(item);
      listProductsDTO.add(productDTO);
    }
    return listProductsDTO;
  }

  public List<ProductDTO> toNewListProductsDTO(List<ProductDTO> list) {
    ProductDTO productDTO = null;
    List<ProductDTO> listProductsDTO = new LinkedList<ProductDTO>();
    for (ProductDTO item : list) {
      productDTO = this.toNewProductDTO(item);
      listProductsDTO.add(productDTO);
    }
    return listProductsDTO;
  }
}
