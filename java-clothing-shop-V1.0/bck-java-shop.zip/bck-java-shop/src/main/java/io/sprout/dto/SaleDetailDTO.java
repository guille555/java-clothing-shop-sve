package io.sprout.dto;

public class SaleDetailDTO {

  private Short ammount;
  private Float unitPrice;
  private SaleDTO sale;
  private ProductDTO product;

  public SaleDetailDTO() {
    this.ammount = 0;
    this.unitPrice = 0f;
    this.sale = null;
    this.product = null;
  }

  public SaleDetailDTO(Short ammount, ProductDTO product) {
    this.ammount = ammount;
    this.product = product;
  }

  public SaleDetailDTO(Short ammount, Float unitPrice, SaleDTO sale, ProductDTO product) {
    this.ammount = ammount;
    this.unitPrice = unitPrice;
    this.sale = sale;
    this.product = product;
  }

  public Short getAmmount() {
    return ammount;
  }

  public Float getUnitPrice() {
    return unitPrice;
  }

  public SaleDTO getSale() {
    return sale;
  }

  public ProductDTO getProduct() {
    return product;
  }
}
