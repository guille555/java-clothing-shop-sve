package io.sprout.repository.record;

import java.util.Date;
import java.util.List;

public record CategoryRecord(
  String public_key,
  String name,
  boolean flag_state,
  boolean flag_visible,
  Date create_date,
  Date last_update,
  List<ProductRecord> list_products
) {

  public String public_key() {
    return public_key;
  }

  public String name() {
    return name;
  }

  public boolean flag_state() {
    return flag_state;
  }

  public boolean flag_visible() {
    return flag_visible;
  }

  public Date create_date() {
    return create_date;
  }

  public Date last_update() {
    return last_update;
  }

  public List<ProductRecord> list_products() {
    return list_products;
  }
}
