package io.sprout.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.sprout.dto.ProductDTO;
import io.sprout.facade.ProductFacade;

@RestController
@RequestMapping("/api/product")
public class ProductController {

  @Autowired
  private ProductFacade facade;

  @GetMapping(path = { "/find_all" }, produces = { MediaType.APPLICATION_JSON_VALUE })
  public ResponseEntity<List<ProductDTO>> findAllByFilters(
    @RequestParam(name = "id", required = false, defaultValue = "") String publicKey,
    @RequestParam(name = "name", required = false, defaultValue = "") String name,
    @RequestParam(name = "flag_state", required = false, defaultValue = "true") boolean flagState,
    @RequestParam(name = "flag_visible", required = false, defaultValue = "true") boolean flagVisible,
    @RequestParam(name = "category_public_key", required = false, defaultValue = "") String categoryPublicKey
  ) {
    List<ProductDTO> listProductsDTO = this.facade.findAllByFilters(publicKey, name, flagState, flagVisible, categoryPublicKey);
    ResponseEntity<List<ProductDTO>> response = new ResponseEntity<List<ProductDTO>>(listProductsDTO, HttpStatus.OK);
    return response;
  }

  @PostMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<ProductDTO> save(@RequestBody ProductDTO data) {
    ProductDTO productDTO = this.facade.save(data);
    ResponseEntity<ProductDTO> response = new ResponseEntity<ProductDTO>(productDTO, HttpStatus.BAD_REQUEST);
    if (productDTO.getPublicKey() != null) {
      response = new ResponseEntity<ProductDTO>(productDTO, HttpStatus.CREATED);
    }
    return response;
  }

  @PostMapping(
    path = { "/save_bulk" },
    consumes = { MediaType.APPLICATION_JSON_VALUE },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<List<ProductDTO>> saveBulk(@RequestBody List<ProductDTO> list) {
    List<ProductDTO> listProductsDTO = this.facade.saveBulk(list);
    ResponseEntity<List<ProductDTO>> response = new ResponseEntity<List<ProductDTO>>(listProductsDTO, HttpStatus.BAD_REQUEST);
    if (listProductsDTO.size() > 0) {
      response = new ResponseEntity<List<ProductDTO>>(listProductsDTO, HttpStatus.CREATED);
    }
    return response;
  }

  @PutMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<Void> update(@RequestBody ProductDTO data) {
    ProductDTO productDTO = this.facade.update(data);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    if (productDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    return response;
  }

  @PatchMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<Void> shift(@RequestBody ProductDTO data) {
    ProductDTO productDTO = this.facade.shift(data);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    if (productDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    return response;
  }

  @DeleteMapping()
  public ResponseEntity<Void> delete(
    @RequestParam(name = "id", required = true) String publicKey
  ) {
    ProductDTO productDTO = this.facade.delete(publicKey);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    if (productDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.OK);
    }
    return response;
  }
}
