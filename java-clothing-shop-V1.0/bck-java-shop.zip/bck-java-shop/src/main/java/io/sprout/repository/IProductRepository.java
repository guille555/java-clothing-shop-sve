package io.sprout.repository;

import java.util.List;

import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.sprout.model.Product;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface IProductRepository extends JpaRepository<Product, Integer> {

  @Procedure(name = "Product.saveBulk")
  public abstract String saveBulk(
    @Param("par_list_objects") String list
  );

  @Query(value = "SELECT fn_filter_products(:publicKey, :name, :flagState, :flagVisible, :categoryPublicKey);", nativeQuery = true)
  public abstract String findAllByFilters(
    @Param("publicKey") String publicKey,
    @Param("name") String name,
    @Param("flagState") boolean flagState,
    @Param("flagVisible") boolean flagVisible,
    @Param("categoryPublicKey") String categoryPublicKey
  );

  @EntityGraph(value = "Product.selfAttributes")
  public abstract Product findByPublicKey(String publicKey);

  @EntityGraph(value = "Product.selfAttributes")
  public abstract List<Product> findAll();
}
