package io.sprout.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.dto.ProductDTO;
import io.sprout.model.Category;
import io.sprout.model.Product;
import io.sprout.repository.IProductRepository;
import io.sprout.repository.record.CategoryRecord;
import io.sprout.repository.record.ProductRecord;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

@Component
public class ProductService {

  @Autowired
  private IProductRepository repository;
  @Autowired
  private CategoryService serviceCategory;
  @Autowired
  private ObjectMapper mapper;
  @Autowired
  private UtilService util;

  public ProductService() {}

  private Category findCategoryByPublicKey(String publicKey) {
    Category category = this.serviceCategory.findByPublicKey(publicKey);
    return category;
  }

  private Product createNewProduct(ProductDTO information) {
    short ammount = information.getAmmount().shortValue();
    float unitPrice = information.getUnitPrice().floatValue();
    String publicKey = this.util.createPublicKey();
    String name = information.getName().toUpperCase();
    Date date = new Date();
    Product product = new Product();
    product.setPublicKey(publicKey);
    product.setName(name);
    product.setUnitPrice(unitPrice);
    product.setAmmount(ammount);
    product.setFlagState(true);
    product.setFlagVisible(true);
    product.setCreateDate(date);
    return product;
  }

  private ProductRecord createNewProductRecord(ProductDTO information) {
    short ammount = information.getAmmount();
    float unitPrice = information.getUnitPrice();
    String publicKey = this.util.createPublicKey();
    String name = information.getName().toUpperCase();
    CategoryRecord categoryRecord = this.prepareCategoryRecord(information.getCategory().getPublicKey());
    ProductRecord result = new ProductRecord(
      publicKey,
      name,
      unitPrice,
      ammount,
      false,
      false,
      null,
      null,
      categoryRecord
    );
    return result;
  }

  private CategoryRecord prepareCategoryRecord(String publicKey) {
    Category category = this.findCategoryByPublicKey(publicKey);
    if (category.getPublicKey() == null) {
      throw new EmptyStackException();
    }
    CategoryRecord categoryRecord = new CategoryRecord(
      category.getPublicKey(),
      category.getName(),
      category.isFlagState(),
      category.isFlagVisible(),
      category.getCreateDate(),
      category.getLastUpdate(),
      null
    );
    return categoryRecord;
  }

  private Product prepareNewProduct(ProductDTO information) {
    Category category = this.findCategoryByPublicKey(information.getCategory().getPublicKey());
    Product product = this.createNewProduct(information);
    product.setCategory(category);
    return product;
  }

  

  private Product updateProduct(Product product, ProductDTO information) {
    Date date = new Date();
    product.setName(information.getName().toUpperCase());
    product.setUnitPrice(information.getUnitPrice().floatValue());
    product.setAmmount(information.getAmmount().shortValue());
    product.setFlagState(information.getFlagState().booleanValue());
    product.setFlagVisible(information.getFlagVisible().booleanValue());
    product.setLastUpdate(date);
    return product;
  }

  private Product prepareUpdatedProduct(Product product, ProductDTO information) {
    Category category = this.findCategoryByPublicKey(information.getCategory().getPublicKey());
    Product productUpdated = this.updateProduct(product, information);
    productUpdated.setCategory(category);
    return productUpdated;
  }

  private List<ProductRecord> prepareNewListProductsRecords(List<ProductDTO> list) {
    ProductRecord productRecord = null;
    List<ProductRecord> listProductsRecords = new LinkedList<ProductRecord>();
    for (ProductDTO item: list) {
      productRecord = this.createNewProductRecord(item);
      listProductsRecords.add(productRecord);
    }
    return listProductsRecords;
  }

  public Product save(ProductDTO information) {
    Product product = null;
    try {
      product = this.prepareNewProduct(information);
      product = this.repository.save(product);
      return product;
    } catch (Exception exc) {
      product = new Product();
      return product;
    }
  }

  public List<ProductRecord> saveBulk(List<ProductDTO> information) {
    String textListProducts = null;
    String textResultListProducts = null;
    List<ProductRecord> listProductsRecords = null;
    List<ProductRecord> resultListProductsRecords = null;
    try {
      listProductsRecords = this.prepareNewListProductsRecords(information);
      textListProducts = this.mapper.writeValueAsString(listProductsRecords);
      textResultListProducts = this.repository.saveBulk(textListProducts);
      System.out.println(textResultListProducts);
      resultListProductsRecords = this.mapper.readValue(textResultListProducts, new TypeReference<List<ProductRecord>>() {});
      return resultListProductsRecords;
    } catch (Exception exc) {
      resultListProductsRecords = new ArrayList<ProductRecord>();
      return resultListProductsRecords;
    }
  }

  public Product update(ProductDTO information) {
    Product product = null;
    Product productUpdated = null;
    try {
      product = this.findByPublicKey(information.getPublicKey());
      if (product.getId() > 0) {
        productUpdated = this.prepareUpdatedProduct(
          product,
          information
        );
        product = this.repository.save(productUpdated);
      }
      return product;
    } catch (Exception exc) {
      product = new Product();
      return product;
    }
  }

  private Product shiftProduct(Product product, ProductDTO information) {
    product.setFlagState(information.getFlagState().booleanValue());
    product.setFlagVisible(information.getFlagVisible().booleanValue());
    return product;
  }

  public Product shift(ProductDTO information) {
    Product product = null;
    Product productShifted = null;
    try {
      product = this.findByPublicKey(information.getPublicKey());
      if (product.getId() > 0) {
        productShifted = this.shiftProduct(
          product,
          information
        );
        product = this.repository.save(productShifted);
      }
      return product;
    } catch (Exception exc) {
      product = new Product();
      return product;
    }
  }

  public Product delete(String publicKey) {
    Product product = null;
    try {
      product = this.findByPublicKey(publicKey);
      if (product.getId() > 0) {
        this.repository.delete(product);
      }
      return product;
    } catch (Exception exc) {
      product = new Product();
      return product;
    }
  }

  public Product findByPublicKey(String publicKey) {
    Product product = null;
    try {
      product = this.repository.findByPublicKey(publicKey);
      if (product == null) {
        throw new EmptyStackException();
      }
      return product;
    } catch (Exception exc) {
      product = new Product();
      return product;
    }
  }

  public List<ProductRecord> findAllByFilters(
    String publicKey,
    String name,
    boolean flagState,
    boolean flagVisible,
    String categoryPublicKey
  ) {
    String textListProductsRecords = null;
    List<ProductRecord> listProductsRecords = null;
    try {
      textListProductsRecords = this.repository.findAllByFilters(
        publicKey,
        name,
        flagState,
        flagVisible,
        categoryPublicKey
      );
      listProductsRecords = this.mapper.readValue(textListProductsRecords, new TypeReference<List<ProductRecord>>() {});
      return listProductsRecords;
    } catch (Exception exc) {
      listProductsRecords = new ArrayList<ProductRecord>();
      return listProductsRecords;
    }
  }
}
