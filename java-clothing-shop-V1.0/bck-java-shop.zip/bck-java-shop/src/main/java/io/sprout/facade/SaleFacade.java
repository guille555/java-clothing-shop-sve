package io.sprout.facade;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.dto.SaleDTO;
import io.sprout.dto.SaleDetailDTO;
import io.sprout.dto.SaleMapper;
import io.sprout.repository.record.SaleRecord;
import io.sprout.service.SaleService;

@Component
public class SaleFacade {

  @Autowired
  private SaleService service;
  @Autowired
  private SaleMapper mapper;

  public SaleFacade() {}

  public List<SaleDTO> findAll(String publicKey, Date date) {
    float total = 0;
    SaleDTO saleDTO = null;
    List<SaleDTO> listSalesDTO = new LinkedList<SaleDTO>();
    List<SaleRecord> listSalesRecord = this.service.findAll(publicKey, date);
    for (SaleRecord item : listSalesRecord) {
      total = this.service.getTotalPurchase(item);
      saleDTO = this.mapper.toSaleDTO(item, total);
      listSalesDTO.add(saleDTO);
    }
    return listSalesDTO;
  }

  public SaleDTO save(List<SaleDetailDTO> data) {
    List<SaleDetailDTO> listProducts = this.mapper.toNewListSaleDetailDTO(data);
    SaleRecord sale = this.service.save(listProducts);
    float total = this.service.getTotalPurchase(sale);
    SaleDTO saleDTO = this.mapper.toSaleDTO(sale, total);
    return saleDTO;
  }
}
