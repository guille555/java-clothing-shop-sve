package io.sprout.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.EmptyStackException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.sprout.dto.CategoryDTO;
import io.sprout.model.Category;
import io.sprout.repository.ICategoryRepository;
import io.sprout.repository.record.CategoryRecord;
import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;

@Service
public class CategoryService {

  @Autowired
  private ICategoryRepository repository;
  @Autowired
  private ObjectMapper mapper;
  @Autowired
  private UtilService util;

  public CategoryService() {}

  private Category createNewCategory(CategoryDTO information) {
    Date date = new Date();
    String publicKey = this.util.createPublicKey();
    String name = information.getName().toUpperCase();
    Category result = new Category();
    result.setPublicKey(publicKey);
    result.setName(name);
    result.setFlagState(true);
    result.setFlagVisible(true);
    result.setCreateDate(date);
    return result;
  }

  private CategoryRecord createNewCategoryRecord(CategoryDTO information) {
    String publicKey = this.util.createPublicKey();
    String name = information.getName().toUpperCase();
    CategoryRecord result = new CategoryRecord(publicKey, name, false, false, null, null, null);
    return result;
  }

  private List<CategoryRecord> createNewListCategoriesRecords(List<CategoryDTO> listCategoriesDTO) {
    CategoryRecord categoryRecord = null;
    List<CategoryRecord> listCategoryRecord = new LinkedList<CategoryRecord>();
    for (CategoryDTO item : listCategoriesDTO) {
      categoryRecord = this.createNewCategoryRecord(item);
      listCategoryRecord.add(categoryRecord);
    }
    return listCategoryRecord;
  }

  private Category updateCategory(Category category, CategoryDTO information) {
    Date date = new Date();
    category.setName(information.getName().toUpperCase());
    category.setFlagState(information.getFlagState().booleanValue());
    category.setFlagVisible(information.getFlagVisible().booleanValue());
    category.setLastUpdate(date);
    return category;
  }

  private Category shiftCategory(Category category, CategoryDTO information) {
    Date date = new Date();
    category.setFlagVisible(information.getFlagVisible().booleanValue());
    category.setLastUpdate(date);
    return category;
  }

  public Category save(CategoryDTO information) {
    Category category = null;
    try {
      category = this.createNewCategory(information);
      category = this.repository.save(category);
      return category;
    } catch (Exception exc) {
      category = new Category();
      return category;
    }
  }

  public List<CategoryRecord> saveBulk(List<CategoryDTO> information) {
    String textResultRecords = null;
    String textListCategoriesRecords = null;
    List<CategoryRecord> listCategoryRecord = null;
    List<CategoryRecord> resultList = null;
    try {
      listCategoryRecord = this.createNewListCategoriesRecords(information);
      textListCategoriesRecords = this.mapper.writeValueAsString(listCategoryRecord);
      textResultRecords = this.repository.saveBulk(textListCategoriesRecords);
      resultList = this.mapper.readValue(textResultRecords, new TypeReference<List<CategoryRecord>>() {});
      return resultList;
    } catch (Exception exc) {
      resultList = new ArrayList<CategoryRecord>();
      return resultList;
    }
  }

  public Category update(CategoryDTO information) {
    Category category = null;
    Category categoryUpdated = null;
    try {
      category = this.findByPublicKey(information.getPublicKey());
      if ((category.getId() > 0) && (category.getPublicKey() != null)) {
        categoryUpdated = this.updateCategory(
          category,
          information
        );
        category = this.repository.save(categoryUpdated);
      }
      return category;
    } catch (Exception exc) {
      category = new Category();
      return category;
    }
  }

  public Category shift(CategoryDTO information) {
    Category category = null;
    Category categoryShifted = null;
    try {
      category = this.findByPublicKey(information.getPublicKey());
      if ((category.getId() > 0) && (category.getPublicKey() != null)) {
        categoryShifted = this.shiftCategory(
          category,
          information
        );
        category = this.repository.save(categoryShifted);
      }
      return category;
    } catch (Exception exc) {
      category = new Category();
      return category;
    }
  }

  public Category delete(String publicKey) {
    Category category = null;
    try {
      category = this.findByPublicKey(publicKey);
      if ((category.getId() > 0) && (category.getPublicKey() != null)) {
        this.repository.delete(category);
      }
      return category;
    } catch (Exception exc) {
      category = new Category();
      return category;
    }
  }

  public Category findByPublicKey(String publicKey) {
    Category category = null;
    try {
      category = this.repository.findByPublicKey(publicKey);
      if (category == null) {
        throw new EmptyStackException();
      }
      return category;
    } catch (Exception exc) {
      category = new Category();
      return category;
    }
  }

  public List<CategoryRecord> findByFilter(String publicKey, String name, boolean flagState, boolean flagVisible) {
    String textResultRecords = null;
    List<CategoryRecord> listCategoriesRecords = null;
    try {
      name = name.toUpperCase();
      textResultRecords = this.repository.findAllByFilters(
        publicKey,
        name,
        flagState,
        flagVisible
      );
      listCategoriesRecords = this.mapper.readValue(textResultRecords, new TypeReference<List<CategoryRecord>>() {});
      return listCategoriesRecords;
    } catch (Exception exc) {
      listCategoriesRecords = new ArrayList<CategoryRecord>();
      return listCategoriesRecords;
    }
  }

}
