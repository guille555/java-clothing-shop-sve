package io.sprout.repository.record;

import java.util.Date;
import java.util.List;

public record SaleRecord(
  String public_key,
  boolean flag_state,
  boolean flag_visible,
  Date create_date,
  Date last_update,
  List<SaleDetailRecord> list_sale_details
) {

  public String public_key() {
    return public_key;
  }

  public boolean flag_state() {
    return flag_state;
  }

  public boolean flag_visible() {
    return flag_visible;
  }

  public Date create_date() {
    return create_date;
  }

  public Date last_update() {
    return last_update;
  }

  public List<SaleDetailRecord> list_sale_details() {
    return list_sale_details;
  }
}
