package io.sprout.model;

import java.io.Serializable;
import java.util.Objects;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "sale_detail")
public class SaleDetail implements Serializable {

  private static final long serialVersionUID = 5225405251090260273L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "sale_detail_id", nullable = false, insertable = false, updatable = false, unique = true)
  private Long id;
  @Basic(optional = false)
  private short ammount;
  @Column(name = "unit_price", nullable = false)
  private float unitPrice;
  @ManyToOne
  @JoinColumn(
    name = "sale_id",
    referencedColumnName = "sale_id",
    nullable = false,
    foreignKey = @ForeignKey(
      name = "fk_sale_detail_sale"
    )
  )
  private Sale sale;
  @ManyToOne
  @JoinColumn(
    name = "product_id",
    referencedColumnName = "product_id",
    nullable = false,
    foreignKey = @ForeignKey(
      name = "fk_sale_detail_prodcut"
    )
  )
  private Product product;

  public SaleDetail() {}

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public short getAmmount() {
    return ammount;
  }

  public void setAmmount(short ammount) {
    this.ammount = ammount;
  }

  public float getUnitPrice() {
    return unitPrice;
  }

  public void setUnitPrice(float unitPrice) {
    this.unitPrice = unitPrice;
  }

  public Sale getSale() {
    return sale;
  }

  public void setSale(Sale sale) {
    this.sale = sale;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof SaleDetail))
      return false;
    SaleDetail other = (SaleDetail) obj;
    return Objects.equals(id, other.id);
  }

  @Override
  public String toString() {
    return "SaleDetail {}";
  }
}
