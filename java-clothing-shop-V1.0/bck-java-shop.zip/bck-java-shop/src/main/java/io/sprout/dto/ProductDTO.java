package io.sprout.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProductDTO {

  private String publicKey;
  private String name;
  private Float unitPrice;
  private Short ammount;
  private Boolean flagState;
  private Boolean flagVisible;
  private Date createDate;
  private Date lastUpdate;
  private CategoryDTO category;
  private List<SaleDetailDTO> listSalesDetails;

  public ProductDTO() {
    this.publicKey = null;
    this.name = null;
    this.unitPrice = (float) 0;
    this.ammount = 0;
    this.flagState = false;
    this.flagVisible = false;
    this.createDate = null;
    this.lastUpdate = null;
    this.category = null;
    this.listSalesDetails = new ArrayList<SaleDetailDTO>();
  }

  public ProductDTO(
    String name,
    Float unitPrice,
    Short ammount,
    CategoryDTO category
  ) {
    this();
    this.name = name;
    this.unitPrice = unitPrice;
    this.ammount = ammount;
    this.category = category;
  }

  public ProductDTO(
    String publicKey,
    String name,
    Float unitPrice,
    Short ammount,
    Boolean flagState,
    Boolean flagVisible,
    CategoryDTO category
  ) {
    this();
    this.publicKey = publicKey;
    this.name = name;
    this.unitPrice = unitPrice.floatValue();
    this.ammount = ammount;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
    this.category = category;
  }

  public ProductDTO(
    String publicKey,
    Boolean flagState,
    Boolean flagVisible
  ) {
    this();
    this.publicKey = publicKey;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
  }

  public ProductDTO(
    String publicKey,
    String name,
    Float unitPrice,
    Short ammount,
    Boolean flagState,
    Boolean flagVisible,
    Date createDate,
    Date lastUpdate,
    CategoryDTO category,
    List<SaleDetailDTO> listSalesDetails
  ) {
    this.publicKey = publicKey;
    this.name = name;
    this.unitPrice = unitPrice;
    this.ammount = ammount;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
    this.createDate = createDate;
    this.lastUpdate = lastUpdate;
    this.category = category;
    this.listSalesDetails = listSalesDetails;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public String getName() {
    return name;
  }

  public Float getUnitPrice() {
    return unitPrice;
  }

  public Short getAmmount() {
    return ammount;
  }

  public Boolean getFlagState() {
    return flagState;
  }

  public Boolean getFlagVisible() {
    return flagVisible;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public Date getLastUpdate() {
    return lastUpdate;
  }

  public CategoryDTO getCategory() {
    return category;
  }

  public List<SaleDetailDTO> getListSalesDetails() {
    return listSalesDetails;
  }
}
