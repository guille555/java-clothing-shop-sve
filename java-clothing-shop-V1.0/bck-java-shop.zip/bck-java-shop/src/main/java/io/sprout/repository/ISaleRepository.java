package io.sprout.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import io.sprout.model.Sale;
import jakarta.transaction.Transactional;

@Repository
@Transactional
public interface ISaleRepository extends JpaRepository<Sale, Long> {

  @Procedure(name = "Sale.saveSale")
  public abstract String saveSale(
    @Param("par_sale_public_key") String publicKey,
    @Param("par_list_products") String listProducts
  );

  @Query(value = "SELECT fn_filter_sales(:publicKey, :date);", nativeQuery = true)
  public abstract String findAllSalesByFilters(
    @Param("publicKey") String publicKey,
    @Param("date") Date date
  );
}
