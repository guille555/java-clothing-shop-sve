package io.sprout.model;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.NamedAttributeNode;
import jakarta.persistence.NamedEntityGraph;
import jakarta.persistence.NamedEntityGraphs;
import jakarta.persistence.NamedStoredProcedureQueries;
import jakarta.persistence.NamedStoredProcedureQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.ParameterMode;
import jakarta.persistence.StoredProcedureParameter;
import jakarta.persistence.Table;

@Entity
@Table(name = "category")
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
@NamedStoredProcedureQueries({
  @NamedStoredProcedureQuery(
    name = "Category.saveBulk",
    procedureName = "sp_bulk_insert_categories",
    parameters = {
      @StoredProcedureParameter(mode = ParameterMode.IN, name = "par_list_objects", type = String.class),
      @StoredProcedureParameter(mode = ParameterMode.OUT, name = "par_result_list", type = String.class)
    }
  )
})
@NamedEntityGraphs({
  @NamedEntityGraph(
    name = "Category.selfAttributes",
    includeAllAttributes = false,
    attributeNodes = {
      @NamedAttributeNode("id"),
      @NamedAttributeNode("publicKey"),
      @NamedAttributeNode("name"),
      @NamedAttributeNode("flagState"),
      @NamedAttributeNode("flagVisible"),
      @NamedAttributeNode("createDate"),
      @NamedAttributeNode("lastUpdate")
    }
  ),
  @NamedEntityGraph(
    name = "Category.allAttributes",
    includeAllAttributes = true,
    attributeNodes = {
      @NamedAttributeNode("id"),
      @NamedAttributeNode("publicKey"),
      @NamedAttributeNode("name"),
      @NamedAttributeNode("flagState"),
      @NamedAttributeNode("flagVisible"),
      @NamedAttributeNode("createDate"),
      @NamedAttributeNode("lastUpdate"),
      @NamedAttributeNode("listProducts")
    }
  )
})
public class Category extends AbstractSeed implements Serializable {

  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "category_id", nullable = false, insertable = false, updatable = false, unique = true)
  private Short id;
  @Column(length = 32, nullable = false)
  private String name;
  @OneToMany(mappedBy = "category")
  private List<Product> listProducts;

  public Category() {
    super();
    this.listProducts = new LinkedList<Product>();
  }

  public Short getId() {
    return id;
  }

  public void setId(Short id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<Product> getListProducts() {
    return listProducts;
  }

  public void setListProducts(List<Product> listProducts) {
    this.listProducts = listProducts;
  }

  @Override
  public int hashCode() {
    return Objects.hash(id);
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (!(obj instanceof Category))
      return false;
    Category other = (Category) obj;
    return Objects.equals(id, other.id);
  }

  @Override
  public String toString() {
    return "Category {}";
  }

  @Override
  public String objectInfo() {
    StringBuilder builder = new StringBuilder();
    builder.append("Category { ");
    builder.append(" id: ");
    builder.append(this.id);
    builder.append(" publicKey: ");
    builder.append(this.publicKey);
    builder.append(" name: ");
    builder.append(this.name);
    builder.append(" flagState: ");
    builder.append(this.flagState);
    builder.append(" flagVisible: ");
    builder.append(this.flagVisible);
    builder.append(" createDate: ");
    builder.append(this.createDate);
    builder.append(" lastUpdate: ");
    builder.append(this.lastUpdate);
    builder.append(" }");
    return builder.toString();
  }
}
