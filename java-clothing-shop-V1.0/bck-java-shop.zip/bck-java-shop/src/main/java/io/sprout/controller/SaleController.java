package io.sprout.controller;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.sprout.dto.SaleDTO;
import io.sprout.dto.SaleDetailDTO;
import io.sprout.facade.SaleFacade;

@RestController
@RequestMapping("/api/sale")
public class SaleController {

  @Autowired
  private SaleFacade facade;

  @GetMapping(
    path = { "/find_all" },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<List<SaleDTO>> findAll(
    @RequestParam(name = "id", required = false, defaultValue = "") String publicKey,
    @RequestParam(name = "date", required = true)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    LocalDate localDate
  ) {
    Date date = java.sql.Date.valueOf(localDate);
    List<SaleDTO> listSaleDTO = this.facade.findAll(publicKey, date);
    ResponseEntity<List<SaleDTO>> response = new ResponseEntity<List<SaleDTO>>(listSaleDTO, HttpStatus.OK);
    return response;
  }

  @PostMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<SaleDTO> saveSale(@RequestBody List<SaleDetailDTO> list) {
    SaleDTO sale = this.facade.save(list);
    ResponseEntity<SaleDTO> response = new ResponseEntity<SaleDTO>(sale, HttpStatus.BAD_REQUEST);
    if (sale.getPublicKey() != null) {
      response = new ResponseEntity<SaleDTO>(sale, HttpStatus.CREATED);
    }
    return response;
  }
}
