package io.sprout.repository.record;

public record SaleDetailRecord(
  short ammount,
  float unit_price,
  SaleRecord sale,
  ProductRecord product
) {

  public short ammount() {
    return ammount;
  }

  public float unit_price() {
    return unit_price;
  }

  public SaleRecord sale() {
    return sale;
  }

  public ProductRecord product() {
    return product;
  }
}
