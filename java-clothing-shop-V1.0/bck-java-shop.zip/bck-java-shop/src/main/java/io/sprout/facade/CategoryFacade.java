package io.sprout.facade;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import io.sprout.dto.CategoryDTO;
import io.sprout.dto.CategoryMapper;
import io.sprout.model.Category;
import io.sprout.repository.record.CategoryRecord;
import io.sprout.service.CategoryService;

@Component
public class CategoryFacade {

  @Autowired
  private CategoryMapper mapper;
  @Autowired
  private CategoryService service;

  public CategoryFacade() {}

  public CategoryDTO save(CategoryDTO data) {
    Category category = null;
    CategoryDTO information = null;
    CategoryDTO categoryDTO = null;
    try {
      information = this.mapper.toNewCategoryDTO(data);
      category = this.service.save(information);
      categoryDTO = this.mapper.toCategoryDTO(category);
      return categoryDTO;
    } catch (Exception exc) {
      categoryDTO = new CategoryDTO();
      return categoryDTO;
    }
  }

  public List<CategoryDTO> saveBulk(List<CategoryDTO> data) {
    List<CategoryRecord> listCategoriesRecords = null;
    List<CategoryDTO> information = null;
    List<CategoryDTO> listCategoriesDTO = null;
    try {
      information = this.mapper.toNewListCategoryDTO(data);
      listCategoriesRecords = this.service.saveBulk(information);
      listCategoriesDTO = this.mapper.toListCategoryDTO(listCategoriesRecords);
      return listCategoriesDTO;
    } catch (Exception exc) {
      listCategoriesDTO = new ArrayList<CategoryDTO>();
      return listCategoriesDTO;
    }
  }

  public CategoryDTO update(CategoryDTO data) {
    Category categoryUpdated = null;
    CategoryDTO information = null;
    CategoryDTO categoryDTO = null;
    try {
      information = this.mapper.toCategoryDTO(data);
      categoryUpdated = this.service.update(information);
      categoryDTO = this.mapper.toCategoryDTO(categoryUpdated);
      return categoryDTO;
    } catch (Exception exc) {
      categoryDTO = new CategoryDTO();
      return categoryDTO;
    }
  }

  public CategoryDTO shift(CategoryDTO data) {
    Category categoryShifted = null;
    CategoryDTO information = null;
    CategoryDTO categoryDTO = null;
    try {
      information = this.mapper.toCategoryDTO(data);
      categoryShifted = this.service.shift(information);
      categoryDTO = this.mapper.toCategoryDTO(categoryShifted);
      return categoryDTO;
    } catch (Exception exc) {
      categoryDTO = new CategoryDTO();
      return categoryDTO;
    }
  }

  public CategoryDTO delete(String publicKey) {
    Category categoryDeleted = null;
    CategoryDTO categoryDTO = null;
    try {
      categoryDeleted = this.service.delete(publicKey);
      categoryDTO = this.mapper.toCategoryDTO(categoryDeleted);
      return categoryDTO;
    } catch (Exception exc) {
      categoryDTO = new CategoryDTO();
      return categoryDTO;
    }
  }

  public List<CategoryDTO> findAllByFilters(
    String publicKey,
    String name,
    boolean flagState,
    boolean flagVisible
  ) {
    List<CategoryRecord> listCategoriesRecords = this.service.findByFilter(publicKey, name, flagState, flagVisible);
    List<CategoryDTO> listCategoriesDTO = this.mapper.toListCategoryDTO(listCategoriesRecords);
    return listCategoriesDTO;
  }
}
