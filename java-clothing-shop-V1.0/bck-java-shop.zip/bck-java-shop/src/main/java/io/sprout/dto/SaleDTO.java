package io.sprout.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SaleDTO {

  private String publicKey;
  private Boolean flagState;
  private Boolean flagVisible;
  private Float total;
  private Date createDate;
  private List<SaleDetailDTO> listSaleDetails;

  public SaleDTO() {
    this.publicKey = null;
    this.flagState = false;
    this.flagVisible = false;
    this.total = 0f;
    this.createDate = null;
    this.listSaleDetails = new ArrayList<SaleDetailDTO>();
  }

  public SaleDTO(
    String publicKey,
    Boolean flagState,
    Boolean flagVisible,
    Float total,
    Date createDate,
    List<SaleDetailDTO> listSaleDetails
  ) {
    this.publicKey = publicKey;
    this.flagState = flagState;
    this.flagVisible = flagVisible;
    this.total = total;
    this.createDate = createDate;
    this.listSaleDetails = listSaleDetails;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public Boolean getFlagState() {
    return flagState;
  }

  public Boolean getFlagVisible() {
    return flagVisible;
  }

  public Float getTotal() {
    return total;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public List<SaleDetailDTO> getListSaleDetails() {
    return listSaleDetails;
  }
}
