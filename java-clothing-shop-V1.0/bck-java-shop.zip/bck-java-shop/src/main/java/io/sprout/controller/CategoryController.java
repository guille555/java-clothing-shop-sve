package io.sprout.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.sprout.dto.CategoryDTO;
import io.sprout.facade.CategoryFacade;

@RestController
@RequestMapping("/api/category")
public class CategoryController {

  @Autowired
  private CategoryFacade facade;

  public CategoryController() {}

  @GetMapping(
    path = { "/find_all" },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<List<CategoryDTO>> findAllByFilters(
    @RequestParam(name = "id", required = false, defaultValue = "") String publicKey,
    @RequestParam(name = "name", required = false, defaultValue = "") String name,
    @RequestParam(name = "flag_state", required = false, defaultValue = "true") boolean flagState,
    @RequestParam(name = "flag_visible", required = false, defaultValue = "true") boolean flagVisible
  ) {
    List<CategoryDTO> listCategories = this.facade.findAllByFilters(
      publicKey,
      name,
      flagState,
      flagVisible
    );
    ResponseEntity<List<CategoryDTO>> response = new ResponseEntity<List<CategoryDTO>>(listCategories, HttpStatus.OK);
    return response;
  }

  @PostMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<CategoryDTO> save(@RequestBody CategoryDTO data) {
    CategoryDTO categoryDTO = this.facade.save(data);
    ResponseEntity<CategoryDTO> response = new ResponseEntity<CategoryDTO>(categoryDTO, HttpStatus.BAD_REQUEST);
    if (categoryDTO.getPublicKey() != null) {
      response = new ResponseEntity<CategoryDTO>(categoryDTO, HttpStatus.CREATED);
    }
    return response;
  }

  @PostMapping(
    path = { "/save_bulk" },
    consumes = { MediaType.APPLICATION_JSON_VALUE },
    produces = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<List<CategoryDTO>> saveBulk(@RequestBody List<CategoryDTO> data) {
    List<CategoryDTO> listCategoriesDTO = new ArrayList<CategoryDTO>(1);
    ResponseEntity<List<CategoryDTO>> response = new ResponseEntity<List<CategoryDTO>>(listCategoriesDTO, HttpStatus.BAD_REQUEST);
    listCategoriesDTO = this.facade.saveBulk(data);
    if (listCategoriesDTO.size() > 0) {
      response = new ResponseEntity<List<CategoryDTO>>(listCategoriesDTO, HttpStatus.CREATED);
    }
    return response;
  }

  @PutMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<Void> update(@RequestBody CategoryDTO data) {
    CategoryDTO categoryDTO = this.facade.update(data);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    if (categoryDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    return response;
  }

  @PatchMapping(
    consumes = { MediaType.APPLICATION_JSON_VALUE }
  )
  public ResponseEntity<Void> shift(@RequestBody CategoryDTO data) {
    CategoryDTO categoryDTO = this.facade.shift(data);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);;
    if (categoryDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    return response;
  }

  @DeleteMapping
  public ResponseEntity<Void> delete(
    @RequestParam(name = "id", required = true) String publicKey
  ) {
    CategoryDTO categoryDTO = this.facade.delete(publicKey);
    ResponseEntity<Void> response = new ResponseEntity<Void>(HttpStatus.BAD_REQUEST);
    if (categoryDTO.getPublicKey() != null) {
      response = new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
    }
    return response;
  }
}
