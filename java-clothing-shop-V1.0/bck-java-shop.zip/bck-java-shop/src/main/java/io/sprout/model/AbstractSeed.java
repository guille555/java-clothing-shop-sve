package io.sprout.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class AbstractSeed {

  @Column(name = "flag_state", nullable = false)
  protected boolean flagState;
  @Column(name = "flag_visible", nullable = false)
  protected boolean flagVisible;
  @Column(name = "public_key", length = 20, nullable = false)
  protected String publicKey;
  @Column(name = "create_date", nullable = false)
  protected Date createDate;
  @Column(name = "last_update")
  protected Date lastUpdate;

  public AbstractSeed() {
    this.flagState = false;
    this.flagVisible = false;
    this.publicKey = null;
    this.createDate = null;
    this.lastUpdate = null;
  }

  public abstract String objectInfo();

  public boolean isFlagState() {
    return flagState;
  }

  public void setFlagState(boolean flagState) {
    this.flagState = flagState;
  }

  public boolean isFlagVisible() {
    return flagVisible;
  }

  public void setFlagVisible(boolean flagVisible) {
    this.flagVisible = flagVisible;
  }

  public String getPublicKey() {
    return publicKey;
  }

  public void setPublicKey(String publicKey) {
    this.publicKey = publicKey;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  public Date getLastUpdate() {
    return lastUpdate;
  }

  public void setLastUpdate(Date lastUpdate) {
    this.lastUpdate = lastUpdate;
  }
}
