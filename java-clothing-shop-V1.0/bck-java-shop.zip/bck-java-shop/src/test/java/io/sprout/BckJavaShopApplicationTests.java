package io.sprout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BckJavaShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
